const cambiarPagina = () => {
    window.location.href = "../html/informacion-donacion.html"
}