const agrandarFoto = (numero) => {
    let imagenGrande = document.getElementById('imagenGrande'+ numero);
    imagenGrande.style.display = 'block';
}