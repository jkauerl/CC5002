const jsonObject = JSON.parse("../region_comuna.json");


